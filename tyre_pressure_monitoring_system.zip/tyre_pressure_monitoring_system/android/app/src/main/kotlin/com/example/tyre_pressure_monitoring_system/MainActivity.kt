package com.example.tyre_pressure_monitoring_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
