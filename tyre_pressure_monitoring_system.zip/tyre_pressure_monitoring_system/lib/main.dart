import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
      // theme: ThemeData(
      //   fontFamily: GoogleFonts.lato().fontFamily,
      // ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Tyre Pressure Monitoring System",
        ),
      ),
      body: Column(
        children: [
          Container(
            height: 200,
            width: double.infinity,
            color: Color.fromARGB(255, 227, 114, 114),
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  Icons.dangerous,
                  size: 40,
                  color: Colors.black,
                ),
                Text(
                  "Your Tyre Pressure is Very Low. Please Take Necessary Actions",
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
