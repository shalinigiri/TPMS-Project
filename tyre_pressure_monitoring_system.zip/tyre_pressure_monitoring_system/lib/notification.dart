import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: TirePressureMonitoringPage(),
    );
  }
}

class TirePressureMonitoringPage extends StatelessWidget {
  const TirePressureMonitoringPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tire Pressure Monitoring'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            _showNotification(context);
          },
          child: const Text('Show Tire Pressure Alert'),
        ),
      ),
    );
  }

  void _showNotification(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Tire Pressure Alert'),
          content: const Text('Tire pressure is below recommended level.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Dismiss'),
            ),
            TextButton(
              onPressed: () {
                // Add action to handle the alert
              },
              child: const Text('View Details'),
            ),
          ],
        );
      },
    );
  }
}
