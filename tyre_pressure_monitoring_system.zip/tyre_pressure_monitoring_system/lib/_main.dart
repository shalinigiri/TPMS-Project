import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

void main() {
   runApp(const MyApp());
   }

class MyApp extends StatelessWidget {
   const MyApp({super.key});

   @override
   Widget build(BuildContext context) {
     return const MaterialApp(
       debugShowCheckedModeBanner: false,
       home: HomeScreen(),
     );
   }
 }

 class HomeScreen extends StatefulWidget {
   const HomeScreen({super.key});

   @override
   State<HomeScreen> createState() => _HomeScreenState();
 }

 class _HomeScreenState extends State<HomeScreen> {
   double frontLeftTyrePressure = 0.0;
   double frontRightTyrePressure = 0.0;
   double backLeftTyrePressure = 0.0;
   double backRightTyrePressure = 0.0;


   final TextEditingController textEditingController = TextEditingController();

   String ipAddress = "";

   late final Timer timer;
   final Random random = Random();

   @override
   void initState() {
     super.initState();
     timer = Timer.periodic(
       const Duration(seconds: 1),
       (_) => updateValues(),
     );
   }

   updateValues() async {
     if (ipAddress.isNotEmpty) {
       var client = http.Client();
       try {
         var response = await client.get(Uri.https(ipAddress, '/'));
         var decodedResponse =
             jsonDecode(utf8.decode(response.bodyBytes)) as Map;
       } finally {
         client.close();
       }
       setState(() {
         frontLeftTyrePressure = 20 + random.nextInt(5).toDouble();
         frontRightTyrePressure = 20 + random.nextInt(5).toDouble();
         backLeftTyrePressure = 20 + random.nextInt(5).toDouble();
         backRightTyrePressure = 20 + random.nextInt(5).toDouble();

    
       });
     } else {}
   }

   @override
   Widget build(BuildContext context) {
     return SafeArea(
       child: Scaffold(
         backgroundColor: const Color.fromARGB(255, 177, 167, 167),
         body: Padding(
           padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 50),
           child: Column(
             children: [
               Text(
                 "Tyre Pressure Monitoring System",
                 textAlign: TextAlign.center,
                 style: GoogleFonts.lato(
                   fontSize: 30,
                   fontWeight: FontWeight.bold,
                 ),
               ),
               TextFormField(
                 keyboardType: TextInputType.number,
                 onChanged: (value) {
                   setState(() {
                    ipAddress = value;
                   });
                 },
               ),
               Container(
                 height: MediaQuery.of(context).size.height * 0.5,
                 decoration: const BoxDecoration(
                   image: DecorationImage(
                     fit: BoxFit.fitHeight,
                     image: AssetImage("assets/car.png"),
                   ),
                 ),
                 padding: const EdgeInsets.all(20),
                 child: Column(
                   mainAxisAlignment: MainAxisAlignment.end,
                   children: [
                     Row(
                       children: [
                         GestureDetector(
                           onTap: () {
                             Navigator.of(context).push(
                               MaterialPageRoute(
                                 builder: (BuildContext context) =>
                                     const TyreDetailPageScreen(
                                   tyrePosition: "FRONT-LEFT",
                                 ),
                               ),
                             );
                           },
                           behavior: HitTestBehavior.opaque,
                           child: Column(
                             mainAxisAlignment: MainAxisAlignment.center,
                             crossAxisAlignment: CrossAxisAlignment.start,
                             children: [
                               Row(
                                 mainAxisAlignment: MainAxisAlignment.start,
                                 crossAxisAlignment: CrossAxisAlignment.start,
                                 children: [
                                   Text(
                                     frontLeftTyrePressure.toStringAsFixed(0),
                                     style: GoogleFonts.lato(
                                       fontSize: 40,
                                       fontWeight: FontWeight.bold,
                                     ),
                                   ),
                                   Text(
                                     " Pa",
                                     style: GoogleFonts.poppins(
                                       fontSize: 20,
                                       fontWeight: FontWeight.normal,
                                     ),
                                   ),
                                 ],
                               ),
                             ],
                           ),
                         ),
                         const Spacer(),
                         GestureDetector(
                           onTap: () {
                             Navigator.of(context).push(
                               MaterialPageRoute(
                                 builder: (BuildContext context) =>
                                     const TyreDetailPageScreen(
                                   tyrePosition: "FRONT-RIGHT",
                                 ),
                               ),
                             );
                           },
                           behavior: HitTestBehavior.opaque,
                           child: Column(
                             mainAxisAlignment: MainAxisAlignment.center,
                             crossAxisAlignment: CrossAxisAlignment.start,
                             children: [
                               Row(
                                 mainAxisAlignment: MainAxisAlignment.start,
                                 crossAxisAlignment: CrossAxisAlignment.start,
                                 children: [
                                   Text(
                                     frontRightTyrePressure.toStringAsFixed(0),
                                     style: GoogleFonts.lato(
                                       fontSize: 40,
                                       fontWeight: FontWeight.bold,
                                     ),
                                   ),
                                   Text(
                                     " Pa",
                                     style: GoogleFonts.poppins(
                                       fontSize: 20,
                                       fontWeight: FontWeight.normal,
                                     ),
                                   ),
                                 ],
                               ),
//                             ],
//                           ),
//                         ),
/                       ],
                     ),
                     const Spacer(),
                     Row(
                       children: [
                         GestureDetector(
                           onTap: () {
                             Navigator.of(context).push(
                               MaterialPageRoute(
                                 builder: (BuildContext context) =>
                                     const TyreDetailPageScreen(
                                   tyrePosition: "BACK-LEFT",
                                 ),
                               ),
                             );
                           },
                           behavior: HitTestBehavior.opaque,
                           child: Column(
                             mainAxisAlignment: MainAxisAlignment.center,
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Row(
//                                 mainAxisAlignment: MainAxisAlignment.start,
                                 crossAxisAlignment: CrossAxisAlignment.start,
                                 children: [
                                   Text(
                                     backLeftTyrePressure.toStringAsFixed(0),
                                     style: GoogleFonts.lato(
                                       fontSize: 40,
                                       fontWeight: FontWeight.bold,
                                     ),
                                   ),
                                   Text(
                                     " Pa",
                                     style: GoogleFonts.poppins(
                                       fontSize: 20,
                                       fontWeight: FontWeight.normal,
                                     ),
                                   ),
                                 ],
                               ),
                             ],
                           ),
                         ),
                         const Spacer(),
                         GestureDetector(
                           onTap: () {
                             Navigator.of(context).push(
                               MaterialPageRoute(
                                 builder: (BuildContext context) =>
                                    const TyreDetailPageScreen(
                                   tyrePosition: "BACK-RIGHT",
                                 ),
                               ),
                             );
                           },
                           behavior: HitTestBehavior.opaque,
                           child: Column(
                             mainAxisAlignment: MainAxisAlignment.center,
                             crossAxisAlignment: CrossAxisAlignment.start,
                             children: [
                               Row(
                                 mainAxisAlignment: MainAxisAlignment.start,
                                 crossAxisAlignment: CrossAxisAlignment.start,
                                 children: [
                                   Text(
                                     backRightTyrePressure.toStringAsFixed(0),
                                     style: GoogleFonts.lato(
                                       fontSize: 40,
                                       fontWeight: FontWeight.bold,
                                     ),
                                   ),
                                   Text(
                                     " Pa",
                                     style: GoogleFonts.poppins(
                                       fontSize: 20,
                                       fontWeight: FontWeight.normal,
                                     ),
                                   ),
                                 ],
                               ),
                             ],
                           ),
                         ),
                       ],
                     ),
                   ],
                 ),
               ),
               const Spacer(),
             ],
           ),
         ),
       ),
     );
   }
 }

 class TyreDetailPageScreen extends StatefulWidget {
   const TyreDetailPageScreen({
     super.key,
     required this.tyrePosition,
   });

   final String tyrePosition;

   @override
   State<TyreDetailPageScreen> createState() => _TyreDetailPageScreenState();
 }

 class _TyreDetailPageScreenState extends State<TyreDetailPageScreen> {
   double tyrePressure = 0.0;
   double tyreTemperature = 0.0;

   late final Timer timer;
   final Random random = Random();

   @override
   void initState() {
     super.initState();
     timer = Timer.periodic(
       const Duration(seconds: 1),
       (_) => updateValues(),
     );
   }

   updateValues() {
     setState(() {
       tyrePressure = 20 + random.nextInt(5).toDouble();
       tyreTemperature = 30 + random.nextInt(5).toDouble();
     });
   }

   @override
   Widget build(BuildContext context) {
     return SafeArea(
       child: Scaffold(
         backgroundColor: const Color.fromARGB(255, 177, 167, 167),
         appBar: AppBar(
           title: const Text(
             "Warning ⚠",
             textAlign: TextAlign.center,
           ),
           backgroundColor: const Color.fromARGB(255, 238, 38, 23),
         ),
         body: Padding(
           padding: const EdgeInsets.symmetric(
             horizontal: 10,
             vertical: 40,
           ),
           child: Column(
             children: [
               Text(
                 "Your tyre pressure is very low. Please take neccesary actions",
                 textAlign: TextAlign.center,
                 style: GoogleFonts.lato(
                   fontSize: 20,
                   fontWeight: FontWeight.bold,
                   color: Colors.red,
                 ),
               ),
               const SizedBox(
                 height: 30,
               ),
               Container(
                 decoration: BoxDecoration(
                   border: Border.all(
                     color: Colors.blue,
                   ),
                   borderRadius: BorderRadius.circular(30),
                 ),
                 padding: const EdgeInsets.all(15).copyWith(
                   left: 20,
                   right: 20,
                 ),
                 child: Text(
                   "See nearby shops".toUpperCase(),
                   style: GoogleFonts.lato(
                     fontSize: 16,
                     color: Colors.blue,
                   ),
                 ),
               ),
               const Spacer(),
               Row(
                 mainAxisAlignment: MainAxisAlignment.start,
                 crossAxisAlignment: CrossAxisAlignment.start,
                 children: [
                   Visibility(
                     visible: widget.tyrePosition == "FRONT-RIGHT" ||
                         widget.tyrePosition == "BACK-RIGHT",
                     child: Expanded(
                       child: Image(
                         fit: BoxFit.fitHeight,
                         image: AssetImage(
                           widget.tyrePosition == "FRONT-RIGHT"
                               ? "assets/front_right.png"
                               : "assets/back_right.png",
                         ),
                       ),
                     ),
                   ),
                   Expanded(
                     child: Padding(
                       padding: const EdgeInsets.only(left: 30),
                       child: Column(
                         mainAxisAlignment: MainAxisAlignment.start,
                         crossAxisAlignment: CrossAxisAlignment.start,
                         children: [
                           Row(
                             mainAxisAlignment: MainAxisAlignment.start,
                             crossAxisAlignment: CrossAxisAlignment.start,
                             children: [
                               Text(
                                 tyrePressure.toStringAsFixed(0),
                                 style: GoogleFonts.lato(
                                   fontSize: 60,
                                   fontWeight: FontWeight.bold,
                                 ),
                               ),
                               Text(
                                 " Pa",
                                 style: GoogleFonts.poppins(
                                   fontSize: 30,
                                   fontWeight: FontWeight.normal,
                                 ),
                               ),
                             ],
                           ),
                           Row(
                             mainAxisAlignment: MainAxisAlignment.start,
                             crossAxisAlignment: CrossAxisAlignment.start,
                             children: [
                               Text(
                                 tyreTemperature.toStringAsFixed(0),
                                 style: GoogleFonts.lato(
                                   fontSize: 40,
                                   fontWeight: FontWeight.bold,
                                 ),
                               ),
                               Text(
                                 " °C",
                                 style: GoogleFonts.poppins(
                                   fontSize: 25,
                                   fontWeight: FontWeight.normal,
                                 ),
                               ),
                             ],
                           ),
                         ],
                       ),
                     ),
                   ),
                   Visibility(
                     visible: widget.tyrePosition == "FRONT-LEFT" ||
                         widget.tyrePosition == "BACK-LEFT",
                     child: Expanded(
                       child: Image(
                         fit: BoxFit.fitHeight,
                         image: AssetImage(
                           widget.tyrePosition == "FRONT-LEFT"
                               ? "assets/front_left.png"
                               : "assets/back_left.png",
                         ),
                       ),
                     ),
                   ),
                 ],
               ),
             ],
           ),
         ),
       ),
     );
   }
 }
